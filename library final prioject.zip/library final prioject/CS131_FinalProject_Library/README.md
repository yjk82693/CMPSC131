# Penn State Fall 2021 Computer Science 131 Final Project: Library

# Collaborators

### Dohyoung Ko

Section 007R

### Kunjoong(Charlie) Kim

Section 003R

### Jonghyun Choi

Section 013R

### Yoojun Kim

Section 002R

# How to execute the program

<ol>
  <li>Open main.py and execute it</li>
  <li>Select the mode you want by entering corresponding number key</li>
  <li>Follow the instructions given by each mode</li>
  <li>You will get the result and be returned to the main menu</li>
</ol>

# Detailed Structure of the Program

We divided the entire program into several pieces for efficiency and better code-reading for others. This section will describe how each python files in the program works and how all those are interconnected together to produce designated output required by the assignment.

## main.py

This main.py file will control the flow of the entire program. By executing this file, user is able to calculate given five prompts.

1.  Can a student borrow a book on a particular day for a certain number of days?
2.  What are the most borrowed/popular books in the library?
3.  Which books have the highest borrow ratio?
4.  Sorted lists of most borrowed books / books with highest usage ratio.
5.  What are the pending fines at the end of the log/at a specific day in the log?
    Press any other key to exit

Type the number key corresponding to the mode and follow the instructions. main.py file imports all other python files include mode1, mode2, mode3, mode4, mode5, and preprocess module named init.py Then, it uses functions defined inside of each file to produce the output.

## init.py

This init.py file pre-processes the text files given by the system(booklist.txt, librarylog.txt) and construct two different databases called _Book_ and _Student_.

### Book Database

Book database is constructed in the following format.

| Book Name         | Copies with respect to the Time Interval | Book Restrictions | Borrowed and Returned Dates with respect to the Time Interval                                                                                                                                                                                                                                                                                                                                      |
| ----------------- | ---------------------------------------- | ----------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 'Intro to python' | [[1, 2], [45, 3]]                        | True              | [[1, 2], [1, 7], [3, 7], [11, 17], [11, 12], [13, 19], [18, 22], [21, 22], [25, 30], [26, 30], [31, 33], [34, 41], [34, 36], [40, 44], [44, 48], [47, 50], [50, 54], [53, 55], [53, 54], [55, 58], [56, 61], [59, 61], [62, 66], [62, 69], [64, 68], [67, 71], [72, 78], [72, 73], [74, 80], [78, 81], [81, 84], [83, 89], [83, 86], [85, 90], [89, 95], [92, 93], [95, 97], [98, 104], [98, 100]] |
| 'Dragon reborn'   | [[1, 1]]                                 | False             | [[166, 199]]                                                                                                                                                                                                                                                                                                                                                                                       |
| 'Cooking 101'     | [[30, 1]]                                | False             | [[50, 55], [56, 71], [74, 80], [81, 101]]                                                                                                                                                                                                                                                                                                                                                          |

The column denoted by _Copies with respect to the Time Interval_ shows how the number of copies of a book has changed as time goes on. For example, [[1, 2], [45, 3]] indicates that on Day 1, there were 2 copies. Then, on Day 45, 2 copies are added so that the total number of copies became 3.

Similarly, the column denoted by _Borrowed and Returned Dates with respect to the Time_ shows the entire record of the borrow-return dates listed in the _librarylog.txt_ file. For example, [[50, 55], [56, 71], [74, 80], [81, 101]] indicates that the book has borrowed for 4 times in total: From Day 50 to 55, 56 to 71, 74 to 80, and 81 to 101.

### Student Database

Next, the Student database is constructed in the following format:

| Student Name | Book Name           | Borrow Date | Expected Return Date | Exact Return Date | Amount of Fines with respect to Time Interval |
| ------------ | ------------------- | ----------- | -------------------- | ----------------- | --------------------------------------------- |
| 'Adam'       | 'Intro to python'   | 1           | 2                    | 2                 | [[1, 0], [2, 0]]                              |
| 'Kendra'     | 'Intro to assembly' | 139         | 146                  | 148               | [[1, 0], [148, 10]]                           |
| 'Bob'        | 'Intro to assembly' | 150         | 157                  | 158               | [[1, 0], [158, 5], [160, 2]]                  |

For each line in _librarylog.txt_ except for the book addition operation, is formatted into this form, which describes brief information about a student's borrow and return data.
The column denoted by _Amount of Fines with respect to Time Interval_ shows how a student's fine has changed with respect to the time. For example, [[1, 0], [158, 5], [160, 2]] indicates that Bob did not have any fine before Day 158. As he returned the book 'Intro to assembly' late, he has a fine of 5 since the Day 158. Then, his fine is reduced to 2 since he paid fine of 3 by Day 160.

## mode1.py

The mode1.py checks if the inputted user could borrow a specific book on particular days. First, the user will input the student name, start borrowing date, number of borrowing days, and book name. Then, the file will check three conditions:

<ol>
<li>The amount of the user's pending fine.</li>
<li>The number of books that the user has borrowed before.</li>
<li>The number of books in the library on certain days.</li>
<li>The number of borrowing days and the book's borrowing restriction</li>
</ol>
If there is no pending fine, the user hasn't borrowed up to 3 books, copies exist in the library on certain days, and the number of borrowing days does not exceed that of the book's borrowing restriction conditions(either 7 or 28 days), the code will print "You can borrow". Otherwise, it will print "You cannot borrow".

## mode2.py

This mode2.py file provides answers to the second prompt: finding the most popular books based on the number of days borrowed by all users of the library. First, the code will generate a list of all books and their total borrow days sorted in descending order. Then, it will return the name of the most popular book.

## mode3.py

This mode3.py is designed to determine the borrowing ratio of the book. To do so, we collected data from files and extracted them in form of a 2D list. From files, we extracted the title of the book and put in list 'book title'
Then, we planned to determine the ratio. It was vital to find the number of books. As some books were added on certain days, we had to consider those changes as well. Hence, we tried to separate values.
We separated values by rented days and total available days(considered amount of books as well). Hence, the equation to find availability was (end of log - first day)×total amount of copy.
The end of the log was 200. When copies were only one, we considered total availability as (200-1)×1 = 199. When changes were applied, however, we had to manipulate the equation. Let's say that there were 2 books at the beginning. Then, another book with the same title was added on day 45. For such a case, we made an equation to adjust.
total availability = (day added - first day)×original amount + (end of log - date added)×changed amount
Let's consider that there was one book at the beginning, but another book with the same title was added on day 45. Then total availability would be (45-1)×1+(200-45)×2
We made a separate list named 'total availability' to put all data in an individual list. The next step was to find the total amount of use. When we get data, it is saved on a column like this: [3, 5],[4, 8], or [2, 16], which is in form of [a, b]. Through such a method, we tried to find the total amount of time borrowed. 'a' represents the borrowed date, and 'b' represents returning date.
In one column, our goal is to determine the total amount of time, calculating each element under one book. Borrowed time would be b-a. To calculate the total time for rent, we used for loops to go for every possible time per borrow. When it comes to an example, it would be like this.
[5-3]+[8-4]+[16-2] = 3+4+14 = 21 Hence, total time for rent is 21.
Again, we collected these data to a separate list 'borrowed'. Then we made a list ratio. I made another separate list 'ratio' With for loop, we repeated the process of finding borrowed/total availability.
With in for loop, we made function for book ratio. for i in range(len(borrowed)): d = (borrowed[i]/total availability[i]) ratiotest.append(d)
With that, we got a list containing ratios. Then we made a 2D list that would save the book title in the first column and ratio in the second column.
After that, by using for loop, we compared ratio(second column of 2D-list) and determined max value, as well as book title with that ratio. Through that, the title of a book with the highest ratio and specific value will be printed.

## mode4.py

With a 2D list shaped in mode3, mode4 will sort them in descending order, comparing numbers of ratio. The value we wanted was in the second column. Hence, we designed a program to sort by the second column in descending order.
Based on what we learned in class, we used the algorithm of selection sort. We designated the initial value and made a program to replace the position whenever a bigger element appeared. We used a nested loop to execute the complicated process of comparing and sorting the second column of the 2D list.

## mode5.py

This mode5.py file has functions that address the pending fines at a selected date. It iterates through all student borrow/return data from the Student database and add current amount of fine to the list where the name and fine is given in pairs. As the code transverses through the list, the fine will be added to the list. Then, the _getFineByIndex_ function finds the fine accumulated before the given date. The code eventually prints out the list of [person's name, his/her amount of fine].
