# Collaborators : Dohyoung Ko, Kunjoong(Charlie) Kim, Jonghyun Choi, Yoojun Kim

def sortlist(ratio_comparison):
    order = len(ratio_comparison)
    for i in range(order):
        for j in range(order-i-1):
            if(ratio_comparison[j][1] < ratio_comparison[j+1][1]):
                temp = ratio_comparison[j]
                ratio_comparison[j] = ratio_comparison[j+1]
                ratio_comparison[j+1] = temp
    return ratio_comparison
