# Collaborators : Dohyoung Ko, Kunjoong(Charlie) Kim, Jonghyun Choi, Yoojun Kim

def getPopularBooks(Book):
    # Most borrowed books = days borrowed in total
    borrowList = []
    # Iterate through all books in the database
    for i in range(len(Book)):
        obj = Book[i]
        borrowTime = 0
        for timeTuple in obj[3]:
            borrowTime += (timeTuple[1]-timeTuple[0])
        borrowList.append([obj[0], borrowTime])
    return borrowList


def getMaxBorrowed(borrowList):
    maxTime = -1
    maxBook = ""
    for item in borrowList:
        if item[1] > maxTime:
            maxTime = item[1]
            maxBook = item[0]
    return maxBook


def selection(array, isIncreasing):
    for i in range(0, len(array)-1):
        Index = i
        if isIncreasing:
            # Index with minimum
            for j in range(i, len(array)):
                if array[Index][1] > array[j][1]:
                    Index = j
        else:
            # Index with maximum
            for j in range(i, len(array)):
                if array[Index][1] < array[j][1]:
                    Index = j
        # Swapping
        temp = array[i]
        array[i] = array[Index]
        array[Index] = temp
    return array
